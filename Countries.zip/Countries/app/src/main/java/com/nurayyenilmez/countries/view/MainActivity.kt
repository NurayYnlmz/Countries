package com.nurayyenilmez.countries.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.nurayyenilmez.countries.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}