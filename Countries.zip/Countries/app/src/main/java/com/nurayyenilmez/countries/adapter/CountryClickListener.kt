package com.nurayyenilmez.countries.adapter

import android.view.View

interface CountryClickListener {
    fun onCountryClicked(v: View)
}